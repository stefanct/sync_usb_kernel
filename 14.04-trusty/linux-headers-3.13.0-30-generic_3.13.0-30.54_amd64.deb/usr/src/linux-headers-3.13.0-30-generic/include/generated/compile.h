/* This file is auto generated, version 54 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#54 SMP Fri Jun 27 14:59:20 CEST 2014"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "misery"
#define LINUX_COMPILER "gcc version 4.6.3 (Ubuntu/Linaro 4.6.3-1ubuntu5) "
